
void printBST(BST *T){
	printNode(T->Head,0);
}




void printNode(Node * N,int spaces){
	int j;
	if(N==NULL) return;
	printNode(N->Right,spaces+1);
	for(j=0;j<spaces;j++){
		printf(BSTSPACES);
	}
	printf(BSTPRINTSTRING"\n",N->data);
	printNode(N->Left,spaces+1);
}

