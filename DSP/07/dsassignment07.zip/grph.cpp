# include <cstdio>
# include <cstring>
# include <cmath>
# include <cstdlib>
# include <iostream>
# include <vector>
# include <algorithm>
# include <queue>
# include <set>
# include <map>
# include <list>
# include <ctime>

#define MaxGraphSize 100 // <-- change this for smaller graphs

#define REP(var,max) for(var=0;var<(max);var++)
using namespace std;

int main(){
    int R,T,**W,k=1,E,i,j;
    scanf("%d",&R);
	printf("%d\n",R);
	while(R--){
		T=(rand()%MaxGraphSize)+5;
   		W=new int*[T];
		REP(i,T){
			W[i]=new int[T];
		}
		srand (time(NULL)+k);
		REP(i,T){
			REP(j,T){
				W[i][j]=rand()%246;
			}
			W[i][i]=0;
		}
		printf("%d\n",T);
		REP(i,T){
			REP(j,T){
				printf("%d %d %d\n",i,j,W[i][j]);
			}
		}
		E=rand()%10+3;
		printf("%d\n",E);
		REP(i,E){
			printf("Exp# %d: %d\n",k++,rand()%T);
		}
		
		REP(i,T){
			delete(W[i]);
		}
		delete(W);
	}
   	return 0;
}

