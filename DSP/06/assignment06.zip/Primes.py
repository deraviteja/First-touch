import math 
def isEven(n):
    return n%2==0

def isPrime(n):
    Dmax = math.sqrt(n)
    if n == 2:
        return True
    if isEven(n):
        return False
    d = 3
    while n%d != 0 and d <= Dmax:
        d += 2
    return d > Dmax

def primeList(nMax):
    return [n for n in range(2,nMax) if isPrime(n)]

def demo():
    n=24
    if n<10:
        primes = primeList(n*111111)
    else:
        primes = primeList(n*101010+n/10)
#    primes = primeList(100)
    for p in primes:
        print '%d'%(p)
    
if __name__ == '__main__':
    demo()
    
