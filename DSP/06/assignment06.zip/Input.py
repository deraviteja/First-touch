import random
P=range(1,2**24)
random.shuffle(P)
for p in P:
    print "%d"%(p)
